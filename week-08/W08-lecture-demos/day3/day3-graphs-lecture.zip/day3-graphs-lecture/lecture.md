# Week 8 Day 3

## Getting Started

---

I love interaction and taking great notes to look back on, here is a follow along note sheet that you can use throughout the lecture for today. I will also be slacking out a filled out version as well but you will take notes personalized for yourself way better than I can! Feel free to add ideas and questions/answers to this file as needed! Now let's learn about graphs!

Need help with writing Markdown?? [Here](https://www.markdownguide.org/cheat-sheet/) is a great link!

---

## What are the differences between Graphs and Trees?

---

Even though trees are simply a type of graph, there are big differences between the two that we must be aware of, what are the three main differences?

    -
    -
    -

Here are some examples of graphs that could NOT be considered trees

![graph image #1](graphs.png)

Why can Graph 1 not be considered a tree?

    -

Why can Graph 2 not be considered a tree?

    -

Why can Graph 3 not be considered a tree?

    -

## Different types of Graphs

Complete || Connected Graph - there is an edge from a vertex to any other vertex

Dense Graph - edge count is > number of Vertices

Sparse Graph - edge count is <= number of Vertices

![Dense v Sparse](https://inviqa.com/sites/default/files/inline-images/edges.png)

source: inviqa.com

---

Directed Graph || Digraph - edges on a digraph have a specified direction

Undirected || Unordered || Graph - edges do not have a specified direction

If not specified, all graphs are assumed to be undirected

![Directed v Undirected](https://www.researchgate.net/profile/Debojoti_Kuzur/publication/282653028/figure/fig2/AS:282176378687493@1444287499817/Directed-and-Undirected-graph-Ref-7.png)

source: researchgate.net

---

### Graphs that are not trees do not have ***parent child*** relationships, instead they have ***neighbor*** relationships

---

## How do we create a Graph?

The creation of a graph node is very similer to the creation of a tree node.

```javascript

    class GraphNode {
        constructor(val){
            //things in here
        }
    }
    

    let a = new GraphNode('a');
    let b = new GraphNode('b');
    let c = new GraphNode('c');
    let d = new GraphNode('d');
    let e = new GraphNode('e');
    let f = new GraphNode('f');


    //how do we create the edges?


```

## Another way to show the edges is an adjacency matrix:


```javascript

    let matrix = [
    /*          A       B       C       D       E       F   */
    /*A*/    [true,  true,   true,   false,  true,   false],
    /*B*/    [false, true,   false,  false,  false,  false],
    /*C*/    [false, true,   true,   true,   false,  false],
    /*D*/    [false, false,  false,  true,   false,  false],
    /*E*/    [true,  false,  false,  false,  true,   false],
    /*F*/    [false, false,  false,  false,  true,   true]
    ];

```


## An adjacency list is a very common way to show the connecting nodes!

```javascript

  let graph = {
    'a': ['b', 'c', 'e'],
    'b': [],
    'c': ['b', 'd'],
    'd': [],
    'e': ['a'],
    'f': ['e']
    };

```

---

## What is a set and why do we use it?

---

A set is a data stucture in JS that give us constant time lookup, similar to an object only it assigns values as keys and can not have duplicate values

---

Sets are good for graph traversal because:

    -
    -
    -

The two main methods of a Set are:

    -
    -

We create a set using the following syntax

```javascript
    const s = new Set();
```