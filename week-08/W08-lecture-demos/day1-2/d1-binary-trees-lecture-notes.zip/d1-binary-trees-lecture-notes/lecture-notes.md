# Week 8 Day 1

## Getting Started

---

I love interaction and taking great notes to look back on, here is a follow along note sheet that you can use throughout the lecture for today. I will also be slacking out a filled out version as well but you will take notes personalized for yourself way better than I can! Feel free to add ideas and questions/answers to this file as needed! Now let's learn about binary trees!

Need help with writing Markdown?? [Here](https://www.markdownguide.org/cheat-sheet/) is a great link!

---

## Let's start from the root (pun totally intended)

---
What are the two pieces of a graph?

    1. 
    2. 

What can a Graph do that a Tree can not do?

    -
---

### Let's play the fun game of IS THIS A GRAPH

---

![graph image #1](is-it-a-graph-1.PNG)

    Answer: 

![graph image #2](is-it-a-graph-2.PNG)

    Answer:

![graph image #3](is-it-a-graph-3.PNG)

    Answer:

![graph image #4](is-it-a-graph-4.PNG)

    Answer:

Great Job! Before we go on with trees here are some major notes regarding graphs before we move on:

    -

---

## Now to the real root (Tree root that is)

---

Let's get the basic vocabulary out of the way.

    tree - 
    binary tree - 
    root - 
    parent/internal node - 
    leaf - 
    path - 

We can use the file system on our computers to visualize a tree! "Tom" is our root, think of root directory! Data, and Tools are both parent/internal nodes. One.txt, Two.txt, etc. are all leaf nodes.

![tree file image](tree_file-example.jpg)

---

## How do we even create a node??

---

A node is simply just a class that we need to create! We have created classes before and dare I say we are masters at the syntax!

```javascript
    
```

Similar to a linked list we have to tell each node where they are in the tree, so lets look at the properties that this TreeNode class needs!

    1. 
    2. 
    3. 

Now that we have the anatomy of our node class thought out, lets create our node class!

```javascript
    class TreeNode {
        constructor(value){

        }
    }
```

We have our node class, which is pretty cool, now lets start to build our tree.

    ```javascript
        // Let's build our tree!
        let a = new TreeNode("a")
        let b = new TreeNode("b")
        let c = new TreeNode("c")
        let e = new TreeNode("e")
        let f = new TreeNode("f")
        let g = new TreeNode("g")

        a.left = b
        a.right = c
        b.left = e
        b.right = f
        f.right = g

    ```

As an exercise for visualizing what we are writing, try to think about what our tree now looks like!

---

### We have our tree, now how do we use it?

---

There are two ways to search a tree, they are...

    1. Breadth-frst search
    2. Depth-first search

---

### Breadth-first Search

---

When thinking about breadth-first search we can think of how we read a book, we start at the top of the page, going left to right, working our way down. The same goes for trees, start at the root node, go down working from left to right.

With our beautiful tree we made, let's think of how we can do a breadth-first traversal.

    []

---

### Depth-first Searches

---

There are three types of Depth-first traversals

    1. Pre-order
    2. In-order
    3. Post-order

We can classify then using three words

    self - the node that we are currently on
    left - the node to the left of our current node
    right - the node to the right of our current node

---

### Pre-order

---

the order of pre-order traversal is...

    - 

When looking at our tree from before we would traverse the tree like this...

    []

---

### In-order

---

the order of in-order traversal is...

    - 

When looking at our tree from before we would traverse the tree like this...

    []

---

### Post-order

---

the order of Post-order traversal is...

    - 

When looking at our tree from before we would traverse the tree like this...

    []

---

## The Almighty Binary Search Tree

---

Binary search trees are just like binary trees, except for these differences!

    - 

---

### Let's make our own BST

---

    ```javascript
        let bstTree = new BST();

        bstTree.insert(11);
        bstTree.insert(8);
        bstTree.insert(14);
        bstTree.insert(5);
        bstTree.insert(6);
        bstTree.insert(14);


    ```

As an exercise for visualizing what we are writing, try to think about what our tree now looks like!

Let's see how the order in which we insert nodes changes the way our tree evolves.
