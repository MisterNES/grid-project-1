147
(1 * 10^2) + (4  * 10^1) + (7 * 10^0)


11 0101
(1*2^5) + (1*2^4)+(0*2^3) + (1*2^2)+(0*2^1) + (1*2^0)
32+16+4+1 = 53

// 0101
// (0*2^3) + (1*2^2)+(0*2^1) + (1*2^0)
// 32+16+4+1 = 53


0-9,A-F
F2
(15*16^1) + (2*16^0)
240+2 = 242


19 to binary
Smallest digit: 19 / 2 = 9 + remainder 1 => 1
Next: 9 / 2 = 4 + remainder 1 => 1
Next: 4 / 2 = 2 + remainder 0 => 0
Next: 2 / 2 = 1 + remainder 0 => 0
Next: 1 / 2 = 0 + remainder 1 => 1
Overall representation: 10011
Check: (1 * 2^4) + (1*2^1) + (1*2^0) = 16 + 2 + 1 = 19


19 to hexadecimal
Smallest digit: 19 / 16 = 1 + remainder 3 => 3
Next: 1 / 16 = 0 + remainder 1 => 1
Overall representation: 13
Check: (1*16^1) + (3*16^0) = 16 + 3 = 19


In computer architecture:
most significant bit
|
11 0101
      |
least significant bit


IPv4: 0100
IPv6: 0110
