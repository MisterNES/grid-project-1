class GraphNode {
    constructor(val) {
        this.val = val;
        this.neighbors = [];
    }
}

module.exports = { GraphNode };